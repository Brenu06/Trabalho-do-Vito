public class MenorCaminhoCapitais {

}
